import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import oscP5.*; 
import netP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class LOGOTOP5_008 extends PApplet {




OscP5 oscP5;

NetAddress myRemoteLocation;

int sizeX = 700;
int sizeY = 700;

public void setup() {
	size(sizeX, sizeY,P3D);
	oscP5 = new OscP5(this, 12000);
}

public synchronized void draw() {
	background(150);
}

public synchronized void oscEvent(OscMessage theOscMessage) {
    String path = theOscMessage.addrPattern();
    String[] splitted = path.split("/");

    //println("splitted: "+splitted);
    
    String breedName = splitted[1];
    //println("breedName: "+breedName);
    String varName = splitted[2].toLowerCase();

    // if (varName.equals("ycor")){
    //   eventCounter++;
    // }
    
    char[] types = theOscMessage.typetag().toCharArray();
    int id = theOscMessage.get(0).intValue();
    Object varValue = null;
    
    OscArgument arg = theOscMessage.get(1);
    println("arg: "+arg);
    switch(types[1]) {
      case 'f':
        varValue = arg.floatValue();
        break;
      case 's':
        varValue = arg.stringValue();
        break;
      default:
        varValue = arg;
        break;
    }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "LOGOTOP5_008" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
